/*******************************************************************************
 * Copyright (c) 2016 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Arnault Lapitre (CEA LIST) arnault.lapitre@cea.fr
 *   - Initial API and implementation
 *******************************************************************************/
/*
 * ExpressionConstructorTest.cpp
 *
 *  Created on: 17 juil. 2015
 *      Author: lapitre_is148245
 */

#include <fml/common/Form.h>

#include <fml/executable/InstanceOfData.h>

#include <fml/numeric/Numeric.h>

#include <fml/expression/ExpressionConstructor.h>
#include <fml/expression/ExpressionConstructorImpl.h>

#include <fml/type/TypeManager.h>
#include <utest/ExpressionConstructorTest.h>


namespace sep
{


void ExpressionConstructorTest::startImpl()
{
	RUN_TEST_UNIT( numericConstructor );

	RUN_TEST_UNIT( numConstructor );

	RUN_TEST_UNIT( numNativeConstructor );

	RUN_TEST_UNIT( exprConstructor );

	RUN_TEST_UNIT( exprNativeConstructor );

	RUN_TEST_UNIT( predicatNativeConstructor );

//	startBF();

}


/**
 * NATIVE NUMERIC EXPRESSION CONSTRUCTOR
 */
void ExpressionConstructorTest::numericConstructor()
{
	basicTest("Numeric:> ", "512", "512", Numeric("512"));
	try
	{
		basicTest("Numeric:> ", "5.12", "5", Numeric("5.12"));
	}
	catch( const std::exception & e )
	{
		AVM_OS_WARN << EMPHASIS(
			"Numeric< std::exception > ",
			e.what(), '*', 80);
	}

	basicTest("Numeric:> ", "NULL", "0", Numeric(0));

	basicTest("Numeric:> ", "5/12", "5/12", Numeric("5/12"));

	basicTest("Numeric:> ", "5.12", "5.12", Numeric("5.12"));

	basicTest("Numeric:> ", "512/100", "128/25", Numeric("512/100"));
}


void ExpressionConstructorTest::numConstructor()
{
	basicTest("newInteger    :> ", "512", "512",
			ExpressionConstructor::newExprInteger("512"));
	try
	{
		basicTest("newInteger    :> ", "5.12", "5",
				ExpressionConstructor::newExprInteger("5.12"));
	}
	catch( const std::exception & e )
	{
		AVM_OS_WARN << EMPHASIS(
			"ExpressionConstructorTest::exprConstructor< std::exception > ",
			e.what(), '*', 80);
	}

	basicTest("newInteger    :> ", "NULL", "0",
			ExpressionConstructor::newExprInteger(NULL));


	basicTest("newRational   :> ", "5.12", "128/25",
			ExpressionConstructor::newExprRational("5.12"));
	basicTest("newRational   :> ", "5/12", "5/12",
			ExpressionConstructor::newExprRational("5/12"));

	basicTest("newRational   :> ", "NULL", "0",
			ExpressionConstructor::newExprRational(NULL));


	basicTest("newFloat      :> ", "5.12", "5.12",
			ExpressionConstructor::newExprFloat("5.12"));

	basicTest("newFloat      :> ", "NULL", "0.0",
			ExpressionConstructor::newExprFloat(NULL));


	basicTest("newExprNumber:> ", "5.12", "128/25",
			ExpressionConstructorNative::newExprNumber("5.12"));

	basicTest("newExpr       :> ", "5.12", "128/25",
			ExpressionConstructor::newExpr("5.12"));
}


void ExpressionConstructorTest::numNativeConstructor()
{
	basicTest("newInteger    :> ", "512", "512",
			ExpressionConstructorNative::newInteger("512"));
	try
	{
		basicTest("newInteger    :> ", "5.12", "5",
				ExpressionConstructorNative::newInteger("5.12"));
	}
	catch( const std::exception & e )
	{
		AVM_OS_WARN << EMPHASIS(
			"ExpressionConstructorTest::nativeConstructor< std::exception > ",
			e.what(), '*', 80);
	}

	basicTest("newRational   :> ", "5.12", "128/25",
			ExpressionConstructorNative::newRational("5.12"));
	basicTest("newRational   :> ", "5/12", "5/12",
			ExpressionConstructorNative::newRational("5/12"));

	basicTest("newFloat      :> ", "5.12", "5.12",
			ExpressionConstructorNative::newFloat("5.12"));

	basicTest("newExprNumber:> ", "5.12", "5.12",
			ExpressionConstructorNative::newExprNumber("5.12"));
}


/**
 * NATIVE EXPRESSION CONSTRUCTOR
 */
void ExpressionConstructorTest::exprConstructor()
{

}

void ExpressionConstructorTest::exprNativeConstructor()
{
	AvmCode::this_container_type vec;

	BF A( new InstanceOfData(
			IPointerDataNature::POINTER_STANDARD_NATURE,
			TypeManager::INTEGER, "A", 0) );

	BF B( new InstanceOfData(
			IPointerDataNature::POINTER_STANDARD_NATURE,
			TypeManager::INTEGER, "B", 0) );

	BF X( new InstanceOfData(
			IPointerDataNature::POINTER_STANDARD_NATURE,
			TypeManager::INTEGER, "X", 0) );

	BF Y( new InstanceOfData(
			IPointerDataNature::POINTER_STANDARD_NATURE,
			TypeManager::INTEGER, "Y", 0) );

	vec.append(A, B, A);
	basicEval("newExpr:> ", "A + B + A",
			ExpressionConstructorNative::addExpr( vec ));
	basicEval("newExpr:> ", "A * B * A",
			ExpressionConstructorNative::multExpr( vec ));

	vec.clear();
	vec.append(A, B, ExpressionConstructorNative::uminusExpr(A));
	basicEval("newExpr:> ", "A + B - A",
			ExpressionConstructorNative::addExpr( vec ));
	basicEval("newExpr:> ", "A * B * (-A)",
			ExpressionConstructorNative::multExpr( vec ));

	vec.clear();
	vec.append(ExpressionConstructorNative::uminusExpr(A), B,
			ExpressionConstructorNative::uminusExpr(A));
	basicEval("newExpr:> ", "-A + B + (-A)",
			ExpressionConstructorNative::addExpr( vec ));
	basicEval("newExpr:> ", "(-A) * B * (-A)",
			ExpressionConstructorNative::multExpr( vec ));

	vec.clear();
	vec.append(ExpressionConstructorNative::uminusExpr(A), A, B,
			ExpressionConstructorNative::uminusExpr(A));
	basicEval("newExpr:> ", "-A +  A + B + (-A)",
			ExpressionConstructorNative::addExpr( vec ));
	basicEval("newExpr:> ", "(-A) * A * B * (-A)",
			ExpressionConstructorNative::multExpr( vec ));
}


void ExpressionConstructorTest::predicatNativeConstructor()
{
	AvmCode::this_container_type vec;

	vec.append(ExpressionConstant::BOOLEAN_FALSE);

	basicEval("newPred:> ", "false",
			ExpressionConstructorNative::orExpr( vec ));

	vec.append(ExpressionConstant::BOOLEAN_FALSE);

	basicEval("newPred:> ", "false || false",
			ExpressionConstructorNative::orExpr( vec ));


	vec.append(ExpressionConstant::BOOLEAN_FALSE);

	basicEval("newPred:> ", "false || false || false",
			ExpressionConstructorNative::orExpr( vec ));



	vec.clear();

	vec.append(ExpressionConstant::BOOLEAN_TRUE);

	basicEval("newPred:> ", "true",
			ExpressionConstructorNative::andExpr( vec ));

	vec.append(ExpressionConstant::BOOLEAN_TRUE);

	basicEval("newPred:> ", "true && true",
			ExpressionConstructorNative::andExpr( vec ));


	vec.append(ExpressionConstant::BOOLEAN_TRUE);

	basicEval("newPred:> ", "true && true && true",
			ExpressionConstructorNative::andExpr( vec ));

}



////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

void ExpressionConstructorTest::startBF()
{
	BF bf( ExpressionConstructor::newInteger(1234567) );
	std::cout << "bf( 1234567 )" << std::endl;
	std::cout << "BF:<" << bf.getRefCount() << "> " << bf.str() << std::endl;

	BFCode code1( OperatorManager::OPERATOR_PLUS , bf , bf );
	std::cout << "code = bf + bf" << std::endl;
	std::cout << "BFCode1:<" << code1.getRefCount() << "> " << code1.str() << std::endl;
	std::cout << "BF:<" << bf.getRefCount() << "> " << bf.str() << std::endl;

//	bf = code1;
	std::cout << "bf = code" << std::endl;
	std::cout << "BF:<" << bf.getRefCount() << "> " << bf.str() << std::endl;
	std::cout << "BFCode1:<" << code1.getRefCount() << "> " << code1.str() << std::endl;

	bf = ExpressionConstructor::newInteger(3);
	std::cout << "bf = 3" << std::endl;
	std::cout << "BF:<" << bf.getRefCount() << "> " << bf.str() << std::endl;
	std::cout << "BFCode1:<" << code1.getRefCount() << "> " << code1.str() << std::endl;

	BFCode code2( OperatorManager::OPERATOR_MULT , code1 , bf );
	std::cout << "code = code * bf" << std::endl;
	std::cout << "BFCode1:<" << code1.getRefCount() << "> " << code1.str() << std::endl;
	std::cout << "BFCode2:<" << code2.getRefCount() << "> " << code2.str() << std::endl;
	std::cout << "BF:<" << bf.getRefCount() << "> " << bf.str() << std::endl;

	code1 = BFCode::REF_NULL;
	std::cout << "BFCode1:<" << code1.getRefCount() << "> " << code1.str() << std::endl;
	std::cout << "BFCode2:<" << code2.getRefCount() << "> " << code2.str() << std::endl;


	Form * aFilterForm = NULL;

	AvmPointer< Form , DestroyElementPolicy > testAPForm;
	BF bf1( aFilterForm );

	testAPForm = bf1;

//	BF bf2;
//	bf2 = testAPForm;

	AvmPointer< Integer , DestroyElementPolicy > aspBF( new Integer(999888) );
	BFCode codeX( OperatorManager::OPERATOR_PLUS , bf , bf );

	BF C1( ExpressionConstructor::notExpr(aspBF) );

	BF C2( ExpressionConstructor::notExpr(bf) );

	BF C3( ExpressionConstructor::notExpr(codeX) );

	AvmPointer< Element , DestroyElementPolicy > aspF(aFilterForm);

	//aspF = aspBF;
	bf1 = BF(aspBF);
	bf1 = BF(aspF);

//	bf1 = aspF;
}


} /* namespace sep */
