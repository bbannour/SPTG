/*******************************************************************************
 * Copyright (c) 2016 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Arnault Lapitre (CEA LIST) arnault.lapitre@cea.fr
 *   - Initial API and implementation
 *******************************************************************************/
/*
 * ExpressionGinacTest.h
 *
 *  Created on: 17 juil. 2015
 *      Author: lapitre_is148245
 */

#ifndef AVM_TEST_EXPRESSIONGINACTEST_H_
#define AVM_TEST_EXPRESSIONGINACTEST_H_

#if defined( _AVM_EXPRESSION_GINAC_ )

#include <utest/AbstractTestUnit.h>


namespace sep
{


class ExpressionGinacTest  :  public AbstractTestUnit
{

public:
	/**
	 * CONSTRUCTOR / DESTRUCTOR
	 */
	ExpressionGinacTest(OutStream & os)
	: AbstractTestUnit( os , "ExpressionGinac" )
	{
		//!!! NOTHING
	}

	virtual ~ExpressionGinacTest()
	{
		//!!! NOTHING
	}

	/**
	 * MAIN TEST LAUNCHER
	 */
	virtual void startImpl();


	/**
	 * OLD
	 */
	void start1();

	void start2();


	void start3();
	void start4();
	void start5();

	void start6();

};


} /* namespace sep */

#endif /* _AVM_EXPRESSION_GINAC_ */

#endif /* AVM_TEST_EXPRESSIONGINACTEST_H_ */
