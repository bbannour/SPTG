/*******************************************************************************
 * Copyright (c) 2016 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Arnault Lapitre (CEA LIST) arnault.lapitre@cea.fr
 *   - Initial API and implementation
 *******************************************************************************/
/*
 * ExpressionNumericTest.h
 *
 *  Created on: 30 juil. 2015
 *      Author: al203168
 */

#ifndef UTEST_EXPRESSIONNUMERICTEST_H_
#define UTEST_EXPRESSIONNUMERICTEST_H_

#include <utest/AbstractTestUnit.h>


namespace sep
{

class ExpressionNumericTest  :  public AbstractTestUnit
{

public:
	/**
	 * CONSTRUCTOR / DESTRUCTOR
	 */
	ExpressionNumericTest(OutStream & os)
	: AbstractTestUnit( os , "ExpressionNumeric" )
	{
		//!!! NOTHING
	}

	virtual ~ExpressionNumericTest()
	{
		//!!! NOTHING
	}

	/**
	 * MAIN TEST LAUNCHER
	 */
	virtual void startImpl();


	void start_integer();

	void start_rational();

	void start_float();

	void start_mix();

};

} /* namespace sep */

#endif /* UTEST_EXPRESSIONNUMERICTEST_H_ */
