/*******************************************************************************
 * Copyright (c) 2016 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Arnault Lapitre (CEA LIST) arnault.lapitre@cea.fr
 *   - Initial API and implementation
 *******************************************************************************/
/*
 * avm_test.cpp
 *
 *  Created on: 9 juin 2009
 *      Author: lapitre_is005667
 */

#include <utest/AvmTest.h>
#include <utest/ExpressionConstructorTest.h>
#include <utest/ExpressionNumericTest.h>
#include <utest/SolverTest.h>

#if defined( _AVM_EXPRESSION_GINAC_ )

#include <utest/ExpressionGinacTest.h>

#endif /* _AVM_EXPRESSION_GINAC_ */

#include <boost/filesystem.hpp>
#include <boost/shared_ptr.hpp>

#include <tr1/memory>

#include <util/avm_vfs.h>
#include <common/BF.h>

#include <fml/expression/AvmCode.h>
#include <fml/expression/ExpressionConstructor.h>

#include <fml/operator/OperatorManager.h>

#include <util/BoostFactory.h>


namespace sep
{


void AvmTest::start()
{
	AVM_OS_COUT << EMPHASIS( "AVM TEST MODE !!!" , '*' , 80 );

	ExpressionNumericTest numTester(AVM_OS_COUT);
	numTester.start();

	ExpressionConstructorTest ctorTester(AVM_OS_COUT);
	ctorTester.start();


//#if defined( _AVM_EXPRESSION_GINAC_ )
//
//	ExpressionGinacTest ginacTester(AVM_OS_COUT);
//	ginacTester.start();
//
//#endif /* _AVM_EXPRESSION_GINAC_ */


//	SolverTest solverTester(AVM_OS_COUT);
//	solverTester.start();

//    avm_test::start_smart_pointer();

//    avm_test::startBoost();
}



void test_boost_path(boost::filesystem::path & path)
{
	std::cout << "\t" << "is_complete" << ":>" << path.is_complete() << std::endl;
	std::cout << "\t" << "has_root_path" << ":>" << path.has_root_path() << std::endl;
	std::cout << "\t" << "has_root_directory" << ":>" << path.has_root_directory() << std::endl;
	std::cout << "\t" << "has_root_name" << ":>" << path.has_root_name() << std::endl;
	std::cout << "\t" << "has_relative_path" << ":>" << path.has_relative_path() << std::endl;
	std::cout << "\t" << "has_branch_path" << ":>" << path.has_branch_path() << std::endl;

	std::cout << std::endl;

	std::cout << "\t" << "begin" << ":>" << ( * (path.begin()) ) << std::endl;
	std::cout << "\t" << "root_path" << ":>" << path.root_path().string() << std::endl;
	std::cout << "\t" << "root_directory" << ":>" << path.root_directory() << std::endl;
	std::cout << "\t" << "root_name" << ":>" << path.root_name() << std::endl;
	std::cout << "\t" << "relative_path" << ":>" << path.relative_path().string() << std::endl;
	std::cout << "\t" << "branch_path" << ":>" << path.branch_path().string() << std::endl;
	std::cout << "\t" << "native_path" << ":>" << VFS::native_path(path.string()) << std::endl;
	std::cout << "\t" << "cygwin_path" << ":>" << VFS::posix_path(path.string()) << std::endl;
}

void AvmTest::startBoost()
{
	std::string platform( BoostFactory::PLATFORM );
	std::cout << "PLATFORM:>" << platform << std::endl;

	platform = ( platform == "Win32" || platform == "Win64" || platform == "Cygwin" ) ? "WINDOWS" : "POSIX";
	std::cout << "PLATFORM:>" << platform << std::endl;

	boost::filesystem::path path;

#if( BOOST_FILESYSTEM_VERSION == 2 )
	path = boost::filesystem::path( "D:/diversity/agatha.sh" , boost::filesystem::native );
#else
	path = boost::filesystem::path( "D:/diversity/agatha.sh" );
#endif
	std::cout << "NATIVE:>" << path.string() << std::endl;
	test_boost_path(path);

#if( BOOST_FILESYSTEM_VERSION == 2 )
	path = boost::filesystem::path( "D:agatha/agatha.sh" , boost::filesystem::native );
#else
	path = boost::filesystem::path( "D:agatha/agatha.sh" );
#endif
	std::cout << "NATIVE:>" << path.string() << std::endl;
	test_boost_path(path);

#if( BOOST_FILESYSTEM_VERSION == 2 )
	path = boost::filesystem::path( "D:\\agatha\\agatha.sh" , boost::filesystem::native );
#else
	path = boost::filesystem::path( "D:\\agatha\\agatha.sh" );
#endif
	std::cout << "NATIVE:>" << path.string() << std::endl;
	test_boost_path(path);

#if( BOOST_FILESYSTEM_VERSION == 2 )
	path = boost::filesystem::path( "//diversity/agatha.sh" , boost::filesystem::native );
#else
	path = boost::filesystem::path( "//diversity/agatha.sh" );
#endif
	std::cout << "WINDOWS:>" << path.string() << std::endl;
	test_boost_path(path);

	path = boost::filesystem::path( "/cygdrive/d/diversity/agatha.sh" );
	std::cout << "CYGWIN:>" << path.string() << std::endl;
	test_boost_path(path);

	path = boost::filesystem::path( "/home/d/diversity/agatha.sh" );
	std::cout << "UNIX:>" << path.string() << std::endl;
	test_boost_path(path);

}


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

typedef AvmCode type;
typedef type* raw_ptr_type;
//typedef BT::wrapper_ptr<type> wrapper_ptr_type;
typedef boost::shared_ptr<type> boost_shared_ptr_type;
typedef std::tr1::shared_ptr<type> tr1_shared_ptr_type;


template<typename T>
void benchmark(T ptr)
{
	T p1 = ptr;
	T p2 = ptr;
	T p3 = ptr;

	if( false )
	{
		p1 = p2 = p3 = p1;
	}
}

void AvmTest::start_smart_pointer()
{
	std::size_t count = 1E7;

	clock_t start, end;
	double diff;

	//raw pointer
	{
		start = clock();
		for (size_t i = 0; i <count ; ++i){
			raw_ptr_type ptr(new type());
			benchmark(ptr);
			delete ptr;
		}
		end = clock();
	}
	diff = static_cast< double >(end-start)/CLOCKS_PER_SEC;
	std::cout << diff << " seconds elapsed for raw pointer." << std::endl;

	//SmartPointer
	{
		start = clock();
		for (size_t i = 0; i < count ; ++i){
			SmartPointer< type , DestroyElementPolicy > ptr(new type());
			benchmark(ptr);
		}
		end = clock();
	}
	diff = static_cast< double >(end-start)/CLOCKS_PER_SEC;
	std::cout << diff << " seconds elapsed for SmartPointer." << std::endl;

	//AvmPointer
	{
		start = clock();
		for (size_t i = 0; i < count ; ++i){
			AvmPointer< type , DestroyElementPolicy > ptr(new type());
			benchmark(ptr);
		}
		end = clock();
	}
	diff = static_cast< double >(end-start)/CLOCKS_PER_SEC;
	std::cout << diff << " seconds elapsed for AvmPointer." << std::endl;

	//BF
	{
		start = clock();
		for (size_t i = 0; i < count ; ++i){
			BF ptr(new type());
			benchmark(ptr);
		}
		end = clock();
	}
	diff = static_cast< double >(end-start)/CLOCKS_PER_SEC;
	std::cout << diff << " seconds elapsed for BF." << std::endl;



//	//BT::wrapper_ptr
//	{
//		start = clock();
//		for (size_t i = 0; i < count ; ++i){
//			wrapper_ptr_type ptr(new type());
//			benchmark(ptr);
//		}
//		end = clock();
//	}
//	diff = static_cast< double >(end-start)/CLOCKS_PER_SEC;
//	std::cout << diff << " seconds elapsed for BT::wrapper_ptr." << std::endl;

	//tr1::shared_ptr
	{
		start = clock();
		for (size_t i = 0; i < count ; ++i)
		{
			tr1_shared_ptr_type ptr(new type());
			benchmark(ptr);
		}
		end = clock();
	}
	diff = static_cast< double >(end-start)/CLOCKS_PER_SEC;
	std::cout << diff << " seconds elapsed for tr1::shared_ptr." << std::endl;

	//boost::shared_ptr
	{
		start = clock();
		for (size_t i = 0; i < count ; ++i)
		{
			boost_shared_ptr_type ptr(new type());
			benchmark(ptr);
		}
		end = clock();
	}
	diff = static_cast< double >(end-start)/CLOCKS_PER_SEC;
	std::cout << diff << " seconds elapsed for boost::shared_ptr." << std::endl;


	//boost::shared_ptr
	{
		AvmPointer< Integer , DestroyElementPolicy > aspBF( new Integer(999888) );
		start = clock();
		for (size_t i = 0; i < count ; ++i)
		{
			BF C1( ExpressionConstructor::newCode(
					OperatorManager::OPERATOR_NOT, aspBF) );
		}
		end = clock();
	}
	diff = static_cast< double >(end-start)/CLOCKS_PER_SEC;
	std::cout << diff << " seconds elapsed for AvmPointer< Integer >." << std::endl;

	//boost::shared_ptr
	{
		BF bf( new Integer(999888) );
		start = clock();
		for (size_t i = 0; i < count ; ++i)
		{
			BF C2( ExpressionConstructor::newCode(
					OperatorManager::OPERATOR_NOT, bf) );
		}
		end = clock();
	}
	diff = static_cast< double >(end-start)/CLOCKS_PER_SEC;
	std::cout << diff << " seconds elapsed for BF< Integer >." << std::endl;

	//boost::shared_ptr
	{
		BF bf( new Integer(999888) );
		start = clock();
		for (size_t i = 0; i < count ; ++i)
		{
			BF C2( ExpressionConstructor::newCode(
					OperatorManager::OPERATOR_NOT, bf) );
		}
		end = clock();
	}
	diff = static_cast< double >(end-start)/CLOCKS_PER_SEC;
	std::cout << diff << " seconds elapsed for BF< Integer >." << std::endl;

	//boost::shared_ptr
	{
		BF bf( new Integer(999888) );
		BFCode code1( OperatorManager::OPERATOR_PLUS , bf , bf );
		start = clock();
		for (size_t i = 0; i < count ; ++i)
		{
			BF C2( ExpressionConstructor::newCode(
					OperatorManager::OPERATOR_NOT, code1) );
		}
		end = clock();
	}
	diff = static_cast< double >(end-start)/CLOCKS_PER_SEC;
	std::cout << diff << " seconds elapsed for BFCode." << std::endl;
}


}
