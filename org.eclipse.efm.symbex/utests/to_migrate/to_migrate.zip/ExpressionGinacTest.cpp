/*******************************************************************************
 * Copyright (c) 2016 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Arnault Lapitre (CEA LIST) arnault.lapitre@cea.fr
 *   - Initial API and implementation
 *******************************************************************************/
/*
 * ExpressionGinacTest.cpp
 *
 *  Created on: 17 juil. 2015
 *      Author: lapitre_is148245
 */

#if defined( _AVM_EXPRESSION_GINAC_ )

#include "ExpressionGinacTest.h"

//#include <fml/type/TypeManager.h>

#include <fml/symbol/Symbol.h>

#include <compat/model/ginac_expression/ExpressionGinac.h>
#include <compat/model/ginac_expression/GinacAnd.h>
#include <compat/model/ginac_expression/GinacForm.h>
#include <compat/model/ginac_expression/GinacNot.h>
#include <compat/model/ginac_expression/GinacOr.h>
#include <compat/model/ginac_expression/GinacRelational.h>
#include <compat/model/ginac_expression/GinacSimplifier.h>


namespace sep
{


void ExpressionGinacTest::startImpl()
{
	RUN_TEST_UNIT( start6 );
}



static void my_print(const GiNaC::ex & e)
{
    std::size_t n = e.nops();

    if( n > 0 )
    {
    	std::cout << "${ ";

		if( GiNaC::is_a<GiNaC::add>(e) )
		{
			std::cout << "+";
		}
		else if( GiNaC::is_a<GiNaC::mul>(e) )
		{
			std::cout << "*";
		}

		else if( GiNaC::is_a<GiNaC::power>(e) )
		{
			std::cout << "^";
		}

		else if( GiNaC::is_a<sep::ginac_relational>(e) )
		{
			if( e.info(GiNaC::info_flags::relation_equal) )
			{
				std::cout << "_ ==_";
			}
			else if( e.info(GiNaC::info_flags::relation_not_equal) )
			{
				std::cout << "_! = _";
			}
			else if( e.info(GiNaC::info_flags::relation_less) )
			{
				std::cout << "_<_";
			}
			else if( e.info(GiNaC::info_flags::relation_less_or_equal) )
			{
				std::cout << "_< = _";
			}
			else if( e.info(GiNaC::info_flags::relation_greater) )
			{
				std::cout << "_>_";
			}
			else if( e.info(GiNaC::info_flags::relation_greater_or_equal) )
			{
				std::cout << "_> = _";
			}

			else
			{
				std::cout << " ginac_relational ";
			}
		}

		else if( GiNaC::is_a<GiNaC::relational>(e) )
		{
			if( e.info(GiNaC::info_flags::relation_equal) )
			{
				std::cout << " ==";
			}
			else if( e.info(GiNaC::info_flags::relation_not_equal) )
			{
				std::cout << "! = ";
			}
			else if( e.info(GiNaC::info_flags::relation_less) )
			{
				std::cout << "<";
			}
			else if( e.info(GiNaC::info_flags::relation_less_or_equal) )
			{
				std::cout << "< = ";
			}
			else if( e.info(GiNaC::info_flags::relation_greater) )
			{
				std::cout << ">";
			}
			else if( e.info(GiNaC::info_flags::relation_greater_or_equal) )
			{
				std::cout << "> = ";
			}

			else
			{
				std::cout << " relational ";
			}
		}

		else if( GiNaC::is_a<GiNaC::function>(e) )
		{
			std::cout << GiNaC::ex_to<GiNaC::function>(e).get_name();
		}



		else
		{
			std::cout << "other:" << GiNaC::ex_to<GiNaC::basic>(e).class_name();
		}

		for( size_t i = 0 ; i < n ; ++i )
		{
			std::cout << " ";
			my_print(e.op(i));
		}

//		GiNaC::const_iterator endIt = e.end();
//		for( GiNaC::const_iterator it = e.begin(); it != endIt; ++it)
//		{
//			std::cout << " ";
//			my_print(*it);
//		}


		std::cout << " }";
    }


	else if( GiNaC::is_a<sep::GinacSymbolForm>(e) )
	{
		std::cout << "vufi:"
				<< GiNaC::ex_to<sep::GinacSymbolForm>(e).rawSymbol()->getFullyQualifiedNameID();
	}

	else if( GiNaC::is_a<GiNaC::symbol>(e) )
	{
		std::cout << "v:" << GiNaC::ex_to<GiNaC::symbol>(e).get_name();
	}

	else if( GiNaC::is_a<GiNaC::numeric>(e) )
	{
		std::cout << "n:" << e;
	}


	else if( GiNaC::is_a<sep::GinacForm>(e) )
	{
		std::cout << "bf:" << GiNaC::ex_to<sep::GinacForm>(e);
	}

	else if( GiNaC::is_a<GiNaC::constant>(e) )
	{
		std::cout << "c:" << e;
	}


	else
    {
    	std::cout << e;
    }
  }



void ExpressionGinacTest::start1()
{
	GiNaC::symbol x("x"), y("y"), z("z");

	// do some math

	GiNaC::ex foo = GiNaC::sin(x + 2/(y/x)) + 3/z + 41;
	GiNaC::ex bar = foo + 1;

	GiNaC::ex bar2 = 1;

	std::cout << "foo :> " << foo << std::endl;              // prints "41+sin(x+2*y)+3*z"
	std::cout << "bar :> " << bar << std::endl;              // prints "42+sin(x+2*y)+3*z"
	std::cout << "foo.subs(x == 2) :> " << foo.subs(x == 2) << std::endl; // prints "41+sin(2+2*y)+3*z"
	std::cout << "foo :> " << foo << std::endl;              // prints "41+sin(x+2*y)+3*z"


	GiNaC::symbol a("a"), b("b"), d("d");

	//ex l1 = a && b || c;
	GiNaC::ex l1 = a + foo == 6 + b - d + b;
	std::cout << "l1 :> " << l1 << std::endl;
	std::cout << "l1 :> " << l1 << std::endl;

	l1 = l1.subs(a == b);
	std::cout << "l1 :> " << l1 << std::endl;

	for( GiNaC::const_iterator it = l1.begin() ; it != l1.end() ; ++it )
	{
		std::cout << "sub_expr:> " << (*it) << std::endl;
	}
	std::cout << "lhs - rhs:> " << - (l1.lhs() - l1.rhs()) << std::endl;

	std::cout << "l1.degree(foo) :> " << l1.degree(foo) << std::endl;

	std::cout << "is_a<relational>(l1) :> "
			<< GiNaC::is_a<GiNaC::relational>(l1) << std::endl;

	std::cout << "l1.info(relation) :> "
			<< l1.info(GiNaC::info_flags::relation) << std::endl;

	std::cout << "my_print(l1) :> ";
	my_print(l1);
	std::cout << std::endl;

	{
		GiNaC::parser reader;
		GiNaC::ex e = reader("2*x+sin(y)/(12*x+sin(y))");
		GiNaC::symtab table = reader.get_syms();
		//			GiNaC::symbol x = reader["x"];
		//			GiNaC::symbol y = reader["y"];

		std::cout << "e :> " << e << std::endl;

//		e.toStream(std::cout, " == > toStream:> ");
	}



//	GiNaC::ex e = mystring("Hello, world!");
//	std::cout << is_a<mystring>(e) << std::endl;
//	std::cout << ex_to<basic>(e).class_name() << std::endl;
//	std::cout << e << std::endl;
//	GiNaC::ex another = pow(mystring("One string"), 2*sin(Pi-mystring("Another string")));
//	std::cout << another << std::endl;
//
//
//
//	//GiNaC::symbol x("x"), y("y");
//	GiNaC::ex poly;
//
//	for (int i = 0; i<10; ++i)
//	{
//		poly += factorial(i+16)*pow(x,i)*pow(y,10-i);
//	}
//	std::cout << poly << std::endl;
//
//	std::cout << 2*poly*x << std::endl;
//
//	bar = (2*poly*x).subs(lst(x == 2, y ==foo));
//
//	std::cout << "bar :> " << bar << std::endl;
//	std::cout << "bar.expand() :> " << bar.expand() << std::endl;
//	std::cout << "bar.eval() :> " << bar.eval() << std::endl;
//	std::cout << "bar.evalf() :> " << bar.evalf() << std::endl;
//	std::cout << "bar.evalm() :> " << bar.evalm() << std::endl;
//	std::cout << "bar.eval_integ() :> " << bar.eval_integ() << std::endl;

}




//void avm_test::start2()
//{
//	GiNaC::symbol x("x"), y("y"), z1("z");
//
//	InstanceOfData z("zz", TypeManager::INT32, 0);
//	z.setFullyQualifiedNameID("ZZZZ");
//
//	BFCharacter K( = new Character('K') );
//	GiNaC::ex exK = K;
//
//	AvmCode * code = ExpressionConstructor::newCode(
//			OperatorManager::OPERATOR_WHEN, K, K, K);
//	GiNaC::ex exCode = code;
//	std::cout << "code :> " << code->str() << std::endl;
//
//	// do some math
//
//	GiNaC::ex foo = GiNaC::sin(x + 2/(y/x)) + 300/z+ 3/z + 41;
//	GiNaC::ex bar = foo + exK + exK + exCode * exCode;
//
//	GiNaC::ex bar2 = 1;
//
//	std::cout << GiNaC::tree << GiNaC::dflt << "foo :> " << foo << std::endl;
//	std::cout << "foo.subs(x == 2) :> " << foo.subs(x == 2) << std::endl;
//	std::cout << "foo :> " << foo << std::endl;
//	std::cout << "myfoo :> "; my_print(foo); std::cout << std::endl;
//
//	std::cout << "bar :> " << bar << std::endl;
//	std::cout << "mybar :> "; my_print(bar); std::cout << std::endl;
//
//
//	Element * aForm = GinacFactory::toForm(bar);
//	std::cout << "bar code:> " << aForm->toString() << std::endl;
//
//	GiNaC::ex e = GinacFactory::toGinac(aForm);
//	std::cout << "bar ex:> " << e << std::endl;
//
//	sep::destroyElement(aForm);
//
//	aForm = GinacFactory::toForm(e);
//	std::cout << "bar code2:> " << aForm->toString() << std::endl;
//
//	e = GinacFactory::toGinac(aForm);
//	std::cout << "bar ex2:> " << e << std::endl;
//
//	int N = 0;
//	do
//	{
//		GiNaC::ex s = e;
//
//		std::cout << "Entrez N :> ";
//		std::cin >> N;
//		for( int i = 0 ; i < N ; ++i )
//		{
//			s = s * GinacFactory::toGinac(aForm) + s;
//		}
//
//		AVM_OS_TRACE << "bar exN:> " << s << std::endl;
//	}
//	while( N > 0 );
//
//	sep::destroyElement(aForm);
//
//}



void ExpressionGinacTest::start3()
{
	GiNaC::symbol x("x"), y("y"), z("z");

	GiNaC::ex e;
	GiNaC::relational r;

	e = r = (x + y - 1 > y + 2*x + 8 - 3*z);
	std::cout << "r :> " << e << std::endl;
	e = GinacSimplifier::simplif_relational(r);
	std::cout << "simplif_rel :> " << e << std::endl;

	e = sep::ginac_relational(x + y - 1 , y + 2*x + 8 - 3*z,
			sep::ginac_relational::greater);
	std::cout << "R :> " << e << std::endl;

	e = r = (x + y + x - 1 > y + 2*x);
	std::cout << "r :> " << e << std::endl;
	e = GinacSimplifier::simplif_relational(r);
	std::cout << "simplif_rel :> " << e << std::endl;

	e = sep::ginac_relational(x + y + x - 1 , y + 2*x ,
			sep::ginac_relational::greater);
	std::cout << "R :> " << e << std::endl;

	e = (x - 1 >= 0) * (x >= 0) * (x -5 > 3) + 4;
	std::cout << "e :> " << e << std::endl;
	e = GinacSimplifier::simplif(e);
	std::cout << "simplif :> " << e << std::endl;

	e = sep::ginac_relational(x - 1 , 0 , sep::ginac_relational::greater_or_equal) *
			sep::ginac_relational(x , 0 , sep::ginac_relational::greater_or_equal) *
			sep::ginac_relational(x -5 , 3 , sep::ginac_relational::greater) + 4;
	std::cout << "R :> " << e << std::endl;


	e = ginac_not(sep::ginac_relational(x + y + x - 1 , y + 2*x ,
			sep::ginac_relational::greater));
	std::cout << "e :> " << e << std::endl;

	e = sep::ginac_relational(x + y + x - 1 , y + 20*x ,
			sep::ginac_relational::greater);
	e = ginac_not( e = ginac_not(e));
	std::cout << "e :> " << e << std::endl;

	e = ginac_not(sep::ginac_relational(x + y + x - 1 , y + 2*x ,
			sep::ginac_relational::greater));
	e = ginac_not(e);
	std::cout << "e :> " << e << std::endl;

}



void ExpressionGinacTest::start4()
{
	GiNaC::symbol x("x"), y("y"), z("z");
	GiNaC::ex e;

//	InstanceOfData x("x", TypeManager::INT32, 0);
//	InstanceOfData y("y", TypeManager::INT32, 1);
//	InstanceOfData z("z", TypeManager::INT32, 2);
//
//	BF e;


//	e = sep::ginac_relational(x-5 ,x-5, sep::ginac_relational::greater);
//	std::cout << "e :> " << e << std::endl;

//	e = ginac_and(sep::ginac_relational(x -5 , 3,
//					sep::ginac_relational::greater_or_equal),
//			sep::ginac_relational(x -5 , 3,
//					sep::ginac_relational::greater_or_equal));
//	std::cout << "e :> " << e << std::endl;
//
//	e = ginac_and(GinacFactory::_TRUE_, GinacFactory::_TRUE_);
//	std::cout << "e :> " << e << std::endl;

	GiNaC::exvector v;
	v.push_back( ginac_not(sep::ginac_relational(x , 0,
			sep::ginac_relational::greater_or_equal)) );
//	v.push_back( sep::ginac_relational(x , 0,
//			sep::ginac_relational::greater_or_equal) );
	v.push_back( sep::ginac_relational(x - 1 , -10,
			sep::ginac_relational::greater_or_equal) );
	v.push_back( ginac_not(sep::ginac_relational(x -5 , 3,
			sep::ginac_relational::greater_or_equal)) );
//	v.push_back( GinacFactory::_TRUE_ );
	v.push_back( ginac_not(z) );


//	e = ginac_and(sep::ginac_relational(x , 0, sep::ginac_relational::greater_or_equal),
//			sep::ginac_relational(x - 1 , -10, sep::ginac_relational::greater_or_equal),
//			sep::ginac_relational(x , 0, sep::ginac_relational::greater_or_equal),
//			sep::ginac_relational(x -5 , 3, sep::ginac_relational::equal),
//			z);
//
//	e = ginac_or(v);
//	std::cout << "oe :> " << e << std::endl;
//
//	e = ginac_and(e, ginac_not(e));
//	std::cout << "ae :> " << e << std::endl;
//
//	v.push_back( (e) );
//	e = ginac_or(v);
//	std::cout << "oe :> " << e << std::endl;
//
//	e = ginac_or(v).negate();
//	std::cout << "ne :> " << e << std::endl;
//
//	std::cout << "se :> " << GinacSimplifier::simplif(e) << std::endl << std::endl;
//
//
//
//	e = ginac_and(ginac_not(x), y, ginac_or(x, z));
//	std::cout << "e :> " << e << std::endl;
//sep::ginac_relational::greater_or_equal),
	//									Gin
//	std::cout << "se :> " << GinacSimplifier::simplif(e) << std::endl << std::endl;


	v.clear();
	v.push_back( ginac_not(sep::ginac_relational(x , 0, sep::ginac_relational::greater_or_equal)) );
	v.push_back( sep::ginac_relational(y , 10, sep::ginac_relational::greater_or_equal) );
	v.push_back( sep::ginac_relational(z , 20, sep::ginac_relational::greater_or_equal) );
	v.push_back( sep::ginac_relational(y+z , 15, sep::ginac_relational::less_or_equal) );
	v.push_back( GinacFactory::_TRUE_ );
	v.push_back( ginac_not(z) );
	e = ginac_and(v);
	std::cout << "e :> " << e << std::endl;
	std::cout << "se :> " << GinacSimplifier::simplif(e) << std::endl << std::endl;

	v.clear();
	v.push_back( ginac_not(sep::ginac_relational(x , 0, sep::ginac_relational::greater_or_equal)) );
	v.push_back( sep::ginac_relational(x-y , 10, sep::ginac_relational::greater_or_equal) );
	v.push_back( sep::ginac_relational(z , 20, sep::ginac_relational::greater_or_equal) );
	v.push_back( sep::ginac_relational(x-y+z , 15, sep::ginac_relational::less_or_equal) );
	v.push_back( GinacFactory::_TRUE_ );
	v.push_back( ginac_not(z) );
	e = ginac_and(v);
	std::cout << "e :> " << e << std::endl;
	std::cout << "se :> " << GinacSimplifier::simplif(e) << std::endl << std::endl;

	v.clear();
	v.push_back( ginac_not(sep::ginac_relational(x , 0, sep::ginac_relational::greater_or_equal)) );
	v.push_back( sep::ginac_relational(x-y , 10, sep::ginac_relational::greater_or_equal) );
	v.push_back( sep::ginac_relational(z , 20, sep::ginac_relational::greater_or_equal) );
	v.push_back( sep::ginac_relational(x-y+z , 30, sep::ginac_relational::less_or_equal) );
	v.push_back( GinacFactory::_TRUE_ );
	v.push_back( ginac_not(z) );
	e = ginac_and(v);
	std::cout << "e :> " << e << std::endl;
	std::cout << "se :> " << GinacSimplifier::simplif(e) << std::endl << std::endl;

	v.clear();
	v.push_back( ginac_not(sep::ginac_relational(x , 0, sep::ginac_relational::greater_or_equal)) );
	v.push_back( sep::ginac_relational(x-y , 10, sep::ginac_relational::greater_or_equal) );
	v.push_back( sep::ginac_relational(z , 20, sep::ginac_relational::greater_or_equal) );
	v.push_back( sep::ginac_relational(x-y+z , 40, sep::ginac_relational::less_or_equal) );
	v.push_back( GinacFactory::_TRUE_ );
	v.push_back( ginac_not(z) );
	e = ginac_and(v);
	std::cout << "e :> " << e << std::endl;
	std::cout << "se :> " << GinacSimplifier::simplif(e) << std::endl << std::endl;


	v.clear();
	v.push_back( sep::ginac_relational(x-y , 10, sep::ginac_relational::equal) );
	v.push_back( sep::ginac_relational(y , 20, sep::ginac_relational::equal) );
	v.push_back( sep::ginac_relational(x-2*z-y , 40, sep::ginac_relational::less_or_equal) );
	v.push_back( ginac_not(z) );
	e = ginac_and(v);
	std::cout << "e :> " << e << std::endl;
	std::cout << "se :> " << GinacSimplifier::simplif(e) << std::endl << std::endl;

	v.clear();
	v.push_back( sep::ginac_relational(y , 10, sep::ginac_relational::greater_or_equal) );
	v.push_back( sep::ginac_relational(y , 20, sep::ginac_relational::equal) );
	v.push_back( sep::ginac_relational(x+z-2*y+z , 40, sep::ginac_relational::less_or_equal) );
	v.push_back( ginac_not(z) );
	e = ginac_and(v);
	std::cout << "e :> " << e << std::endl;
	std::cout << "se :> " << GinacSimplifier::simplif(e) << std::endl << std::endl;

	v.clear();
	v.push_back( sep::ginac_relational(y , 100, sep::ginac_relational::greater_or_equal) );
	v.push_back( sep::ginac_relational(y , 20, sep::ginac_relational::equal) );
	v.push_back( sep::ginac_relational(x-y+z , 40, sep::ginac_relational::less_or_equal) );
	v.push_back( ginac_not(z) );
	e = ginac_and(v);
	std::cout << "e :> " << e << std::endl;
	std::cout << "se :> " << GinacSimplifier::simplif(e) << std::endl << std::endl;



	//	GiNaC::wildcard w0(0), w1(1), w2(2);//, w3(3), w4(4);
//	GiNaC::exmap repls;
//	repls.clear();
//	GiNaC::ex s = sep::ginac_relational(x , -10, sep::ginac_relational::greater_or_equal);
//	std::cout << "s :> " << s << std::endl;
//	if( s.match( (w0 >= w1) , repls ) )
//	{
//		std::cout << "m :> " << repls << std::endl;
//	}
//
//	if( s.match( sep::ginac_relational(x, w0, sep::ginac_relational::greater_or_equal) , repls ) )
//	{
//		std::cout << "m' :> " << repls << std::endl;
//	}
//
//	s = (x >= -10);
//	std::cout << "s :> " << s << std::endl;
//	repls.clear();
//	if( s.match( (w0 >= w1) , repls ) )
//	{
//		std::cout << "m'' :> " << repls << std::endl;
//	}


//	std::cout << "e.subs(x == 20) :> " << e.subs(x == 20) << std::endl;
//	std::cout << "e.subs(x == 8) :> " << e.subs(x == 8) << std::endl;
//	std::cout << "e.subs(x == 1) :> " << e.subs(x == 1) << std::endl;
//
//
//	e = ginac_or(sep::ginac_relational(x - 1 , -10, sep::ginac_relational::greater_or_equal),
//			ginac_or(sep::ginac_relational(x , 0, sep::ginac_relational::greater_or_equal),
//					ginac_or(sep::ginac_relational(x , 0, sep::ginac_relational::greater_or_equal),
//							ginac_or(sep::ginac_relational(x -5 , 3,
//									sep::ginac_relational::greater_or_equal),
//									GinacFactory::_FALSE_))));
//
//	std::cout << "e :> " << e << std::endl;
//
//	std::cout << "simplif :> " << simplif_and(e) << std::endl;
//
//	std::cout << "e.subs(x == -20) :> " << e.subs(x == -20) << std::endl;
//	std::cout << "e.subs(x == -9) :> " << e.subs(x == -9) << std::endl;
//	std::cout << "e.subs(x == 1) :> " << e.subs(x == 1) << std::endl;


//	std::cout << "e.subs(x == 2*x - 1234567890) :> " << e.subs(x == 2*x -1234567890) << std::endl;
//
//
//	e = sep::ginac_relational(x -5 , 3, sep::ginac_relational::greater_or_equal);
//	std::cout << "e :> " << e << std::endl;
//	e = e.subs(x == 2);
//	std::cout << "e.subs(x == 2) :> " << e << std::endl;
//
//	e = sep::ginac_relational(x -5 , 3, sep::ginac_relational::greater_or_equal);
//	std::cout << "e :> " << e << std::endl;
//	e = e.subs(x == 2*x -1234567890);
//	std::cout << "e.subs(x == 2*x - 1234567890) :> " << e << std::endl;

}


void ExpressionGinacTest::start5()
{
//	GiNaC::symbol x("x"), y("y"), z("z");
/*
	InstanceOfData X(IPointerDataNature::POINTER_STANDARD_NATURE,
			TypeManager::BOOLEAN, "X", 0);
	InstanceOfData Y(IPointerDataNature::POINTER_STANDARD_NATURE,
			TypeManager::BOOLEAN, "Y", 1);

	GinacSymbolForm x(&X);
	GinacSymbolForm y(&Y);

	GiNaC::ex e;

	ginac_relational a = ginac_relational(x == GinacFactory::_FALSE_);
	ginac_relational b = ginac_relational(ginac_not(y) == x);
	ginac_and c = ginac_and(a, b);

	ginac_relational r = (c == GinacFactory::_TRUE_);

	e = r;
	std::cout << "e:> " << e;
*/
//	GiNaC::ex s = r.lhs();
//
//	e = (x + y - 1 > y + 2*x + 8 - 3*z) + s;
//
//	e = s;
//
//	e = 1;
//
////	BF a = 123456789;
////
////	BF b = a;
//
//	std::cout << "s:> " << s;
}


void ExpressionGinacTest::start6()
{
	GiNaC::symbol w("w"), x("x"), y("y"), z("z");

	{
		GiNaC::ex e, f, g, h;

	//	ginac_and a = ginac_and( ginac_and(w, x) , ginac_and(y, ginac_not(x)) );


		e = ginac_or(ginac_not(x), y);
		std::cout << "subst:> " << e << std::flush;
		std::cout << " ==> " << e.subs( x == GinacFactory::_TRUE_ ) << std::endl;

		e = ginac_or(ginac_not(x), y);
		std::cout << "subst:> " << e << std::flush;
		std::cout << " ==> " << e.subs( x == GinacFactory::_FALSE_ ) << std::endl;


		e = ginac_and(x, ginac_or(x, y));
		std::cout << "and:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;

		f = ginac_and(x, ginac_or(x, y), z);
		std::cout << "and:> " << f << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(f) << std::endl;


		e = ginac_and(ginac_not(x), ginac_or(x, y));
		std::cout << "and:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;

		f = ginac_and(ginac_not(x), ginac_or(x, y), z);
		std::cout << "and:> " << f << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(f) << std::endl;


		e = ginac_and(x, ginac_or(ginac_not(x), y));
		std::cout << "and:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;

		f = ginac_and(x, ginac_or(ginac_not(x), y), z);
		std::cout << "and:> " << f << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(f) << std::endl;


		e = ginac_and(ginac_not(x), ginac_or(ginac_not(x), y));
		std::cout << "and:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;

		f = ginac_and(ginac_not(x), ginac_or(ginac_not(x), y), z);
		std::cout << "and:> " << f << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(f) << std::endl;


//	a = ginac_and(w, x, y, ginac_not(x));
//	e = a;
//	std::cout << "and:> " << e << std::endl;
	}

	std::cout << " ============================================================== "
			<< std::endl;


	{
		GiNaC::ex e, f, g, h;

		e = ginac_and(ginac_not(x), y);
		std::cout << "subst:> " << e << std::flush;
		std::cout << " ==> " << e.subs( x == GinacFactory::_TRUE_ ) << std::endl;

		e = ginac_and(ginac_not(x), y);
		std::cout << "subst:> " << e << std::flush;
		std::cout << " ==> " << e.subs( x == GinacFactory::_FALSE_ ) << std::endl;


		e = ginac_or(x, ginac_and(x, y));
		std::cout << "or:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;

		f = ginac_or(x, ginac_and(x, y), z);
		std::cout << "or:> " << f << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(f) << std::endl;


		e = ginac_or(ginac_not(x), ginac_and(x, y));
		std::cout << "or:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;

		f = ginac_or(ginac_not(x), ginac_and(x, y), z);
		std::cout << "or:> " << f << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(f) << std::endl;


		e = ginac_or(x, ginac_and(ginac_not(x), y));
		std::cout << "or:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;

		f = ginac_or(x, ginac_and(ginac_not(x), y), z);
		std::cout << "or:> " << f << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(f) << std::endl;

		e = f;

		e = ginac_or(ginac_not(x), ginac_and(ginac_not(x), y));
		std::cout << "or:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;

		f = ginac_or(ginac_not(x), ginac_and(ginac_not(x), y), z);
		std::cout << "or:> " << f << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(f) << std::endl;
	}

	std::cout << " ============================================================== "
			<< std::endl;

	{
		GiNaC::ex e, f, g, h;


		e = ginac_and(ginac_or(x, y), ginac_or(ginac_not(x), z), ginac_or(y, z));
		std::cout << "and:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;

		e = ginac_and(ginac_or(x, y), ginac_or(ginac_not(x), z), ginac_or(y, z), w);
		std::cout << "and:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;


		e = ginac_and(ginac_or(x, y), ginac_or(x, ginac_not(y)));
		std::cout << "and:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;

		e = ginac_and(ginac_or(x, y), ginac_or(x, ginac_not(y)), w);
		std::cout << "and:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;



		e = ginac_or(ginac_and(x, y), ginac_and(ginac_not(x), z), ginac_and(y, z));
		std::cout << "or:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;

		e = ginac_or(ginac_and(x, y), ginac_and(ginac_not(x), z), ginac_and(y, z), w);
		std::cout << "or:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;


		e = ginac_or(ginac_and(x, y), ginac_and(x, ginac_not(y)));
		std::cout << "or:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;

		e = ginac_or(ginac_and(x, y), ginac_and(x, ginac_not(y)), w);
		std::cout << "or:> " << e << std::flush;
		std::cout << " ==> " << GinacSimplifier::simplif(e) << std::endl;
	}
}


} /* namespace sep */

#endif /* _AVM_EXPRESSION_GINAC_ */
