/*******************************************************************************
 * Copyright (c) 2016 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Arnault Lapitre (CEA LIST) arnault.lapitre@cea.fr
 *   - Initial API and implementation
 *******************************************************************************/
/*
 * AbstractTestUnit.h
 *
 *  Created on: 30 juil. 2015
 *      Author: al203168
 */

#ifndef UTEST_ABSTRACTTESTUNIT_H_
#define UTEST_ABSTRACTTESTUNIT_H_

#include <printer/OutStream.h>


namespace sep
{

class AbstractTestUnit
{

protected:
	/**
	 * ATTRIBUTE
	 */
	OutStream & OS;

	std::string mContext;

	std::size_t mTotalTestCount;
	std::size_t mTotalPassCount;

	std::size_t mTestCount;
	std::size_t mPassCount;


public:
	/**
	 * CONSTRUCTOR / DESTRUCTOR
	 */
	AbstractTestUnit(OutStream & os, const std::string & aContext)
	: OS( os ),
	mContext( aContext ),

	mTotalTestCount( 0 ),
	mTotalPassCount( 0 ),

	mTestCount( 0 ),
	mPassCount( 0 )
	{
		//!!! NOTHING
	}

	virtual ~AbstractTestUnit()
	{
		//!!! NOTHING
	}


	/**
	 * COUNTER
	 */
	inline void testStart()
	{
		++mTestCount;
		++mTotalTestCount;
	}

	inline void testPass()
	{
		++mPassCount;
		++mTotalPassCount;
	}

	inline void resetCounter()
	{
		mTotalTestCount = 0;
		mTotalPassCount = 0;

		mTestCount = 0;
		mPassCount = 0;
	}


	/**
	 * MAIN TEST LAUNCHER
	 */
	void start();

	virtual void startImpl() = 0;

	void report();


	/**
	 * RUN A TEST
	 */
	template< class T > void basicEval(const std::string & msg,
			const std::string & inExpr, const T & ctrExpr)
	{
		OS << "[ eval ] " << msg << AVM_NO_INDENT
				<< inExpr << " |==> " << ctrExpr << END_INDENT_EOL;
	}


	template< class T > void basicTest(
			const std::string & msg, const std::string & inExpr,
			const std::string & resExpr, const T & ctrExpr)
	{
		testStart();

		std::string outExpr = ctrExpr.str();

		if( resExpr != outExpr )
		{
			OS << "[ fail ] " << msg << AVM_NO_INDENT
					<< inExpr << " |==> " << outExpr
					<< " =/= " << resExpr << END_INDENT_EOL;
		}
		else
		{
			testPass();

			OS << "[ pass ] " << msg << AVM_NO_INDENT
					<< inExpr << " |==> " << outExpr
					<< " === " << resExpr << END_INDENT_EOL;
		}
	}


	void initTester(const std::string & msg);

	void reportTester(const std::string & msg);


#define RUN_TEST_UNIT( tester )    \
	initTester( QUOTEME(tester) ); \
	tester();                      \
	reportTester( QUOTEME(tester) );

};


} /* namespace sep */

#endif /* UTEST_ABSTRACTTESTUNIT_H_ */
