/*******************************************************************************
 * Copyright (c) 2016 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Arnault Lapitre (CEA LIST) arnault.lapitre@cea.fr
 *   - Initial API and implementation
 *******************************************************************************/
/*
 * SolverTest.h
 *
 *  Created on: 17 juil. 2015
 *      Author: lapitre_is148245
 */

#ifndef AVM_TEST_SOLVERTEST_H_
#define AVM_TEST_SOLVERTEST_H_

#include <utest/AbstractTestUnit.h>


namespace sep
{

class SolverTest  :  public AbstractTestUnit
{

public:
	/**
	 * CONSTRUCTOR / DESTRUCTOR
	 */
	SolverTest(OutStream & os)
	: AbstractTestUnit( os , "Solver" )
	{
		//!!! NOTHING
	}

	virtual ~SolverTest()
	{
		//!!! NOTHING
	}

	/**
	 * MAIN TEST LAUNCHER
	 */
	virtual void startImpl();


	bool xbed();


	bool start_yices1();

	bool start_yices2();

	bool start_z3();



};


} /* namespace sep */

#endif /* AVM_TEST_SOLVERTEST_H_ */
