/*******************************************************************************
 * Copyright (c) 2016 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Arnault Lapitre (CEA LIST) arnault.lapitre@cea.fr
 *   - Initial API and implementation
 *******************************************************************************/
/*
 * ExpressionNumericTest.cpp
 *
 *  Created on: 30 juil. 2015
 *      Author: al203168
 */

#include <fml/numeric/Float.h>
#include <fml/numeric/Integer.h>
#include <fml/numeric/Rational.h>
#include <fml/numeric/Numeric.h>
#include <utest/ExpressionNumericTest.h>


namespace sep
{


void ExpressionNumericTest::startImpl()
{
	RUN_TEST_UNIT( start_integer );

	RUN_TEST_UNIT( start_rational );

	RUN_TEST_UNIT( start_float );

	RUN_TEST_UNIT( start_mix );
}


template< class T > void testNumber(OutStream & OS, const T & N)
{
	OS << "[ test ] isInt32( " << N.str()
			<< " ) |=> " << N.isInt32() << std::endl;

	OS << "[ test ] isInt64( " << N.str()
			<< " ) |=> " << N.isInt64() << std::endl;

	OS << "[ test ] isInt00( " << N.str()
			<< " ) |=> " << N.isInteger() << std::endl;

	OS << "[ test ] isInt>=( " << N.str()
			<< " ) |=> " << N.isPosInteger() << std::endl << std::endl;
}

void ExpressionNumericTest::start_integer()
{
	Integer N( "123456789123456789123456789123456789" );

	basicTest("Integer :> ", "123456789123456789123456789123456789",
			"123456789123456789123456789123456789", N);

	testNumber( OS , N );

	testNumber( OS , Integer(AVM_NUMERIC_MAX_UINT) );

	testNumber( OS , Integer(AVM_NUMERIC_MAX_LONG) );

	OS << "10 ** 123 = " << Integer::pow(10, 123) << std::endl;
}


void ExpressionNumericTest::start_rational()
{
	Rational R( "123456789123456789123456789123456789/3" );

	basicTest("Rational :> ", "123456789123456789123456789123456789/3",
			"41152263041152263041152263041152263", R);

	testNumber( OS , R );

	testNumber( OS , Rational(AVM_NUMERIC_MAX_UINT) );

	testNumber( OS , Rational(AVM_NUMERIC_MAX_LONG) );

	Rational S( "123456789123456789123456789.123456788" );

	basicTest("Rational :> ", "30864197280864197280864197280864197/250000000",
			"30864197280864197280864197280864197/250000000", S);

	testNumber( OS , S );


}


void ExpressionNumericTest::start_float()
{
	Float F( "123456789123456789123456789123456789" );

	basicTest("Float :> ", "123456789123456789123456789123456789",
			"123456789123456789123456789123456789", F);

	testNumber( OS , F );

	testNumber( OS , Float(AVM_NUMERIC_MAX_UINT) );

	testNumber( OS , Float(AVM_NUMERIC_MAX_LONG) );
}


void ExpressionNumericTest::start_mix()
{
	//!! TODO
}




} /* namespace sep */
