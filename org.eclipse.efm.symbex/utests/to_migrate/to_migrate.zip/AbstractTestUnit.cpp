/*******************************************************************************
 * Copyright (c) 2016 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Arnault Lapitre (CEA LIST) arnault.lapitre@cea.fr
 *   - Initial API and implementation
 *******************************************************************************/
/*
 * AbstractTestUnit.cpp
 *
 *  Created on: 30 juil. 2015
 *      Author: al203168
 */

#include <utest/AbstractTestUnit.h>

namespace sep
{

/**
 * MAIN TEST LAUNCHER
 */
void AbstractTestUnit::start()
{
	OS << EMPHASIS( "Test< " + mContext + " >" , '>' , 80 );

	resetCounter();

	startImpl();

	report();
}


void AbstractTestUnit::report()
{
	OS << EMPHASIS( (OSS() << ( (mTotalTestCount == mTotalPassCount) ?
			"PASS" : "FAIL" ) << " : " << mPassCount << " / " << mTestCount),
			'=' , 42 );
}


/**
 * RUN A TEST
 */
void AbstractTestUnit::initTester(const std::string & msg)
{
	mTestCount = 0;
	mPassCount = 0;

	OS << REPEAT('+', 42) << std::endl;
}


void AbstractTestUnit::reportTester(const std::string & msg)
{
	OS << "[ " << ( (mTestCount == mPassCount) ? "PASS" : "FAIL" )
			<< " ] > " << mPassCount << " / " << mTestCount
			<< " <=| " << msg << std::endl;
}


} /* namespace sep */
