/*******************************************************************************
 * Copyright (c) 2016 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Arnault Lapitre (CEA LIST) arnault.lapitre@cea.fr
 *   - Initial API and implementation
 *******************************************************************************/
/*
 * SolverTest.cpp
 *
 *  Created on: 17 juil. 2015
 *      Author: lapitre_is148245
 */

#include <common/BF.h>

#include <fml/expression/ExpressionConstructor.h>
#include <fml/executable/InstanceOfData.h>

#include <fml/type/TypeManager.h>

#include <compat/model/xbed/XBED.h>
#include <utest/SolverTest.h>

#if defined( _AVM_SOLVER_YICES_V1_ )
#include <yices1/yices_c.h>
#include <yices1/yicesl_c.h>
#endif /* _AVM_SOLVER_YICES_V1_ */

#if defined( _AVM_SOLVER_YICES_V2_ )
//#include <yices2/yices.h>
#endif /* _AVM_SOLVER_YICES_V2_ */


#if defined( _AVM_SOLVER_Z3_ )
#include <z3/z3.h>
#endif /* _AVM_SOLVER_Z3_ */



namespace sep
{


void SolverTest::startImpl()
{
	if( not start_yices1() )
	{
		OS << EMPHASIS( "TEST< YICES1 > FAILED !!!" , '>' , 80 );
	}

	if( not start_yices2() )
	{
		OS << EMPHASIS( "TEST< YICES2 > FAILED !!!" , '>' , 80 );
	}

	if( not start_z3() )
	{
		OS << EMPHASIS( "TEST< Z3 > FAILED !!!" , '>' , 80 );
	}
}




static void xbed1()
{
	xbed_var_t v1 = XBED::new_variables( 1 );
	xbed_var_t v2 = XBED::new_variables( 1 );
	xbed_var_t v3 = XBED::new_variables( 1 );

	xbed_t u1 = ith_var(v1);
	xbed_t _u1 = mk_var(v1, XBED_TRUE, XBED_FALSE);

	xbed_t u2 = ith_var(v2);
	xbed_t u3 = ith_var(v3);


	xbed_t r1 = mk_op(XBED_AND, u1, u2);

	AVM_OS_TRACE << std::endl << "r1:>" << std::endl;
	XBED::print(AVM_OS_TRACE, r1);
	AVM_OS_TRACE << std::endl << "bdd:r1:>" << std::endl;
	XBED::print(AVM_OS_TRACE, XBED::upall(r1));


	xbed_t r2 = mk_op(XBED_AND, u3, r1);

	AVM_OS_TRACE << std::endl << "r2:>" << std::endl;
	XBED::print(AVM_OS_TRACE, r2);
	AVM_OS_TRACE << std::endl << "bdd:r2:>" << std::endl;
	XBED::print(AVM_OS_TRACE, XBED::upall(r2));


	xbed_t r3 = mk_op(XBED_AND, r1, _u1);

	AVM_OS_TRACE << std::endl << "r3:>" << std::endl;
	XBED::print(AVM_OS_TRACE, r3);
	AVM_OS_TRACE << std::endl << "bdd:r3:>" << std::endl;
	XBED::print(AVM_OS_TRACE, XBED::upall(r3));


	xbed_t r4 = mk_op(XBED_AND, u1, r2);

	AVM_OS_TRACE << std::endl << "r4:>" << std::endl;
	XBED::print(AVM_OS_TRACE, r4);
	AVM_OS_TRACE << std::endl << "bdd:r4:>" << std::endl;
	XBED::print(AVM_OS_TRACE, XBED::upall(r4));
}



bool SolverTest::xbed()
{
	AVM_OS_TRACE << "XBED::INIT" << std::endl;

	XBED::init(1 << 16, 1 << 10);


	xbed1();


	AVM_OS_TRACE << std::endl;

	XBED::done();
	AVM_OS_TRACE << "XBED::DONE" << std::endl;


	BF a( new InstanceOfData(
			IPointerDataNature::POINTER_STANDARD_NATURE,
			TypeManager::INT32, "a", 0) );

	BF b( new InstanceOfData(
			IPointerDataNature::POINTER_STANDARD_NATURE,
			TypeManager::INT32, "b", 0) );

	BF e = ExpressionConstructor::newUInteger( 0 );

	b = a;

//	BF f( b );

	a.destroy();

	e = ExpressionConstructor::newInteger(1);

	return( true );
}


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////



bool SolverTest::start_yices1()
{
	AVM_OS_TRACE << "YICES1::INIT" << std::endl;

#if defined( _AVM_SOLVER_YICES_V1_ )
	yices_context ctx = yices_mk_context();

	yices_type T_bool = yices_mk_type(ctx, "bool");
	yices_type T_int  = yices_mk_type(ctx, "int");
	yices_type T_real = yices_mk_type(ctx, "real");

	yices_var_decl x_decl = yices_mk_var_decl(ctx, "x", T_real);
	yices_var_decl y_decl = yices_mk_var_decl(ctx, "y", T_int);
	yices_var_decl z_decl = yices_mk_var_decl(ctx, "z", T_int);
	yices_var_decl a_decl = yices_mk_var_decl(ctx, "a", T_bool);
	yices_var_decl b_decl = yices_mk_var_decl(ctx, "b", T_bool);

	yices_expr x = yices_mk_var_from_decl(ctx, x_decl);
	yices_expr y = yices_mk_var_from_decl(ctx, y_decl);
	yices_expr z = yices_mk_var_from_decl(ctx, z_decl);
	yices_expr a = yices_mk_var_from_decl(ctx, a_decl);
	yices_expr b = yices_mk_var_from_decl(ctx, b_decl);


	yices_expr args[3];

	// x * 3
	args[0] = x;
	args[1] = yices_mk_num(ctx, 3);
	yices_expr mul1 = yices_mk_mul(ctx, args, 2);

	// y * 6
	args[0] = y;
	args[1] = yices_mk_num(ctx, 6);
	yices_expr mul2 = yices_mk_mul(ctx, args, 2);

	// x * 3 + y * 6 + z
	args[0] = mul1;
	args[1] = mul2;
	args[2] = z;
	yices_expr sum1 = yices_mk_sum(ctx, args, 3);

	// x * 3 + y * 6 + z = 14
	yices_expr eq1 = yices_mk_eq(ctx, sum1, yices_mk_num(ctx, 14));

	// (x * 3 + y * 6 + z = 14) and (a) and (not b)
	args[0] = eq1;
	args[1] = a;
	args[2] = yices_mk_not(ctx, b);
	yices_expr and1 = yices_mk_and(ctx, args, 3);

	// (assert (and  (= (+ (* 3 x) (* 6 y) z) 14)  a (not b) ) )
	yices_assert(ctx, and1);


	// z = 2
	yices_expr eq2 = yices_mk_eq(ctx, z, yices_mk_num(ctx, 2));

	// (assert (= z 2))
	yices_assert(ctx, eq2);

	yices_dump_context(ctx);

	switch(yices_check(ctx))
	{
		case l_true:
		{
			OS << "satisfiable formula" << std::endl;
			yices_model m = yices_get_model(ctx);
			//		  printf("e1 = %d\n", yices_get_value(m, yices_get_var_decl(e1)));
			//		  printf("e2 = %d\n", yices_get_value(m, yices_get_var_decl(e2)));
			yices_display_model(m);
			break;
		}
		case l_false:
		{
			OS << "unsatisfiable formula" << std::endl;
			break;
		}
		case l_undef:
		{
			OS << "unknown satisfiability formula" << std::endl;
			break;
		}
	}


	yices_del_context(ctx);
#endif /* _AVM_SOLVER_YICES_V1_ */

	OS << "YICES1::DONE" << std::endl;

	return( true );
}



bool SolverTest::start_yices2()
{
	AVM_OS_TRACE << "YICES2::INIT" << std::endl;

#if defined( _AVM_SOLVER_YICES_V2_ )


#endif /* _AVM_SOLVER_YICES_V2_ */

	OS << "YICES2::DONE" << std::endl;

	return( true );
}



bool SolverTest::start_z3()
{
	OS << "Z3::INIT" << std::endl;

#if defined( _AVM_SOLVER_Z3_ )
	Z3_config cfg = Z3_mk_config();

	Z3_set_param_value(cfg, "MODEL", "true");

	Z3_context ctx = Z3_mk_context(cfg);

	Z3_set_error_handler(ctx, NULL);

	Z3_del_config(cfg);


	Z3_sort T_bool = Z3_mk_bool_sort(ctx);
	Z3_sort T_int  = Z3_mk_int_sort (ctx);
	//Z3_sort T_real = Z3_mk_real_sort(ctx);

	Z3_symbol x_decl = Z3_mk_string_symbol(ctx, "x");
	Z3_symbol y_decl = Z3_mk_string_symbol(ctx, "y");
	Z3_symbol z_decl = Z3_mk_string_symbol(ctx, "z");
	Z3_symbol a_decl = Z3_mk_string_symbol(ctx, "a");
	Z3_symbol b_decl = Z3_mk_string_symbol(ctx, "b");

	Z3_ast x = Z3_mk_const(ctx, x_decl, T_int);
	Z3_ast y = Z3_mk_const(ctx, y_decl, T_int);
	Z3_ast z = Z3_mk_const(ctx, z_decl, T_int);
	Z3_ast a = Z3_mk_const(ctx, a_decl, T_bool);
	Z3_ast b = Z3_mk_const(ctx, b_decl, T_bool);


	Z3_ast args[3];

	// x * 3
	args[0] = x;
	args[1] = Z3_mk_int(ctx, 3, T_int);
	Z3_ast mul1 = Z3_mk_mul(ctx, 2, args);

	// y * 6
	args[0] = y;
	args[1] = Z3_mk_int(ctx, 6, T_int);
	Z3_ast mul2 = Z3_mk_mul(ctx, 2, args);

	// x * 3 + y * 6 + z
	args[0] = mul1;
	args[1] = mul2;
	args[2] = z;
	Z3_ast sum1 = Z3_mk_add(ctx, 3, args);

	// x * 3 + y * 6 + z = 14
	Z3_ast eq1 = Z3_mk_eq(ctx, sum1, Z3_mk_int(ctx, 14, T_int));

	// (x * 3 + y * 6 + z = 14) and (a) and (not b)
	args[0] = eq1;
	args[1] = a;
	args[2] = Z3_mk_not(ctx, b);
	Z3_ast and1 = Z3_mk_and(ctx, 3, args);

	// (assert (and  (= (+ (* 3 x) (* 6 y) z) 14)  a (not b) ) )
	Z3_assert_cnstr(ctx, and1);


	// z = 2
	Z3_ast eq2 = Z3_mk_eq(ctx, z, Z3_mk_int(ctx, 2, T_int));

	// (assert (= z 2))
	Z3_assert_cnstr(ctx, eq2);

	OS << "CTX :> " << std::endl
			<< Z3_context_to_string(ctx) << std::endl;

	Z3_model m = NULL;

	switch( Z3_check_and_get_model(ctx, &m) )
	{
		case Z3_L_TRUE:
		{
			OS << "satisfiable formula" << std::endl;

			OS << "model :>" << std::endl
					<< Z3_model_to_string(ctx, m) << std::endl;

			break;
		}
		case Z3_L_FALSE:
		{
			OS << "unsatisfiable formula" << std::endl;
			break;
		}
		case Z3_L_UNDEF:
		{
			OS << "unknown satisfiability formula" << std::endl;
			break;
		}
	}


	Z3_del_context(ctx);
#endif /* _AVM_SOLVER_Z3_ */

	OS << "Z3::DONE" << std::endl;

	return( true );
}




} /* namespace sep */
