/*******************************************************************************
 * Copyright (c) 2016 CEA LIST.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *  Arnault Lapitre (CEA LIST) arnault.lapitre@cea.fr
 *   - Initial API and implementation
 *******************************************************************************/
/*
 * ExpressionConstructorTest.h
 *
 *  Created on: 17 juil. 2015
 *      Author: lapitre_is148245
 */

#ifndef AVM_TEST_EXPRESSIONCONSTRUCTORTEST_H_
#define AVM_TEST_EXPRESSIONCONSTRUCTORTEST_H_

#include <utest/AbstractTestUnit.h>


namespace sep
{

class BF;


class ExpressionConstructorTest  :  public AbstractTestUnit
{

public:
	/**
	 * CONSTRUCTOR / DESTRUCTOR
	 */
	ExpressionConstructorTest(OutStream & os)
	: AbstractTestUnit( os , "ExpressionConstructor" )
	{
		//!!! NOTHING
	}

	virtual ~ExpressionConstructorTest()
	{
		//!!! NOTHING
	}

	/**
	 * MAIN TEST LAUNCHER
	 */
	virtual void startImpl();


	/**
	 * NATIVE NUMERIC EXPRESSION CONSTRUCTOR
	 */
	void numericConstructor();

	void numConstructor();

	void numNativeConstructor();

	/**
	 * NATIVE EXPRESSION CONSTRUCTOR
	 */
	void exprConstructor();

	void exprNativeConstructor();

	void predicatNativeConstructor();


	/**
	 * OLD
	 */
	void startBF();

};


} /* namespace sep */

#endif /* AVM_TEST_EXPRESSIONCONSTRUCTORTEST_H_ */
